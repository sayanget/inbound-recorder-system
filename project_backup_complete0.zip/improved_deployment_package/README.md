# Inbound Recorder 改进版部署包

## 包含文件
1. `single_app.py` - 主应用程序文件
2. `inbound.db` - 数据库文件（包含所有数据）
3. `static/` - 静态文件目录（HTML页面等）
4. `requirements.txt` - Python依赖列表
5. `Dockerfile` - Docker镜像构建文件
6. `docker-compose.yml` - Docker Compose配置文件
7. `start.sh` - Linux/macOS启动脚本
8. `start.bat` - Windows启动脚本
9. `启动应用.bat` - 简化的Windows启动脚本
10. `DEPLOYMENT.md` - 详细部署指南

## 部署方式

### 方式1：快速启动（推荐）
双击 `启动应用.bat` 文件即可自动安装依赖并启动应用

### 方式2：Docker部署
```bash
# 构建并启动容器
docker-compose up -d
```

### 方式3：手动部署
```bash
# 安装依赖
pip install -r requirements.txt

# 启动应用
python single_app.py
```

## 环境变量配置
应用支持以下环境变量：
- `SECRET_KEY`: Flask应用密钥
- `DATABASE_PATH`: 数据库文件路径
- `HOST`: 服务器监听地址
- `PORT`: 服务器监听端口

## 访问应用
启动后，在浏览器中访问：
- 本地访问：http://localhost:8080
- 网络访问：http://[你的IP地址]:8080

## 技术支持
如有任何问题，请联系开发者。